<?php
header("Content-Type: application/vnd.ms-excel; name='excel'");
header("Content-disposition:  attachment; filename=corel_analysis.xls");
?>

<?php
include("db_open.php");
//include("validate.php");
include ("functions/functions.php");
?>


<?php

$start_date = $_GET["start_date"];
$end_date = $_GET["end_date"];

?>
  <p align=center><b><font face="Verdana" color="#000080" size="4">Corel Report between interval</font></b></p>

  <table align=center border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#D9D9FF" width="1450" height="9" id="AutoNumber1">
    <tr>
      <tr background="images/title_bar2.gif" class="reporthead">
	    <td align="center">SL No</td>
	    <td align="center">Date</td>
	    <td align="center">Date Time</td>
	    <td align="center">Agent Name</td>
        <td align="center">Customer Type</td>
		<td align="center">Country</td>
	    <td align="center">Customer Name</td>	
        <td align="center">Customer Email</td>
		        <td align="center">Case Number</td>
        <td align="center">Ticket Type</td>

		<td align="center">Phone No</td>
        <td align="center">Alternate Phone</td>
		<td align="center">Call Status</td>	
		<td align="center">Reason for Call</td>		
        <td align="center">Customer Query</td>
		<td align="center">Agent Comments</td>
		<!--<td align="center">Next Action</td>-->
		<td align="center">Sale</td>
		<td align="center">Order No</td>
		<td align="center">Coupon Code</td>
		<td align="center">Sale Type</td>
		<td align="center">Upgrade From</td>
		<td align="center">Upgrade To</td>
		<td align="center">Upgrade Price</td>
		<td align="center">Product</td>
		<!--<td align="center">Product Rate       </td>-->
		<td align="center">Upsell</td>
		<td align="center">Upsell Product</td>
		<!--<td align="center">Upsell Product Rate</td>-->
		<td align="center">Upsell Decline Reason</td>
		<td align="center">Upsell Other Decline Reason</td>
		<td align="center">Shipping</td>
		<td align="center">Shipping Option</td>
		<td align="center">Shipping Rate</td>
        
		<td align="center">Reason For Decline</td>
		<td align="center">Comments</td>
	    <td align="center">Final Price</td>        
	    <td align="center">Support</td>        
	</tr>
    </tr>


<?php
        $sql = "Select c.*,mc.contact_desc,s.status_desc,rf.reason_call_desc,na.nxtaction_desc,ship.shipping_desc as shipping_desc,ship.shipping_price as shipping_price,updecreason.updecreason_desc as updecreason_desc,country.country_desc as country_desc from corel_tracker as c
left join 
means_contact_tbl as mc on mc.contact_id=c.corel_cust_type
left join 
status_tbl as s on s.status_id=c.corel_status
left join 
reason_forcall_tbl as rf on rf.reason_callid=c.corel_reason_call
left join 
corel_nxtaction_tbl as na on na.nxtaction_id=c.corel_nxtaction
left join 
corel_shipping_tbl as ship on ship.shipping_id=c.corel_shipping_type
left join 
`country_tbl` as country on country.country_id=c.corel_country
left join 
corel_updecreason_tbl as updecreason on updecreason.updecreason_id=c.corel_upsell_decreason

	WHERE c.createdon between '$start_date' AND '$end_date'";
	//echo  $sql;
        $r = mysql_query($sql);

        $num  =  mysql_num_rows($r);
        $sno = 1;
        while($num--)
          {
            $thearray=  mysql_fetch_array($r);
            //print_r($thearray);
//die;
?>
              <tr>
        <td align="center"><? echo $sno; ?></td>
        <td align="center"><? echo date('m-d-Y',strtotime($thearray['createdon'])); ?></td>
        <td align="center"><? echo date('m-d-Y H:i:s',strtotime($thearray['createdon'])); ?></td>
        <td align="center"><? echo user_name($thearray['createdby']); ?></td>
        <td align="center"><? echo $thearray ['contact_desc']; ?></td>
		<td align="center"><? if($thearray['country_desc']=="") echo " - "; else echo $thearray['country_desc']; ?></td>
        <td align="center"><? echo ($thearray['corel_cust_name']); ?></td>
        <td align="center"><? echo $thearray ['corel_cust_email']; ?></td>
		<td align="center"><? echo $thearray ['corel_case_number']; ?></td>
        <? 
			$subcatname = "select * from corel_sales_ticket_type where ticket_id =".$thearray ['corel_ticket_type'];
			$getsubcatname = mysql_query($subcatname);
			$res = mysql_fetch_array($getsubcatname)
		?>
		<td align="center"><? echo $res['ticket_desc']; ?></td>
		<td align="center"><? echo $thearray['corel_phone_no']; ?></td>
	    <td align="center"><? echo $thearray['corel_alt_no']; ?></td>
		<td align="center"><? echo $thearray['status_desc'];   ?></td>
		<td align="center"><? echo $thearray['reason_call_desc']; ?></td>
		<td align="center"><? if($thearray['corel_cust_query']=="") echo " - "; else echo $thearray['corel_cust_query']; ?></td>
		<td align="center"><? if($thearray['corel_agent_comm']=="") echo " - "; else echo $thearray['corel_agent_comm']; ?></td>
		<!--<td align="center"><? if($thearray['corel_nxtaction']==0) echo " - "; else echo $thearray['nxtaction_desc']; ?></td>-->
		<td align="center"><? if($thearray['corel_sale']=="") echo " - "; else echo $thearray['corel_sale']; ?></td>	    
		<td align="center"><? if($thearray['corel_orderno']=="") echo " - "; else echo $thearray['corel_orderno']; ?></td>		
		<td align="center"><? if($thearray['corel_promocode']=="") echo " - "; else echo $thearray['corel_promocode']; ?></td>
		      
		<td align="center"><? if($thearray['corel_saletype']=="") echo " - "; else echo $thearray['corel_saletype']; ?></td>	
		<td align="center"><? if($thearray['corel_saletype_from']=="") echo " - "; else echo $thearray['corel_saletype_from']; ?></td>		
		<td align="center"><? if($thearray['corel_saletype_to']=="") echo " - "; else echo $thearray['corel_saletype_to']; ?></td>
		<td align="center"><? if($thearray['corel_saletype_upgradeprice']=="") echo " - "; else echo $thearray['corel_saletype_upgradeprice']; ?></td>
        
		<!---Product---->
		<td align="left">
              <table border=0>
              <tr style="font-family: Verdana; font-size: 8pt; color: #000000" bordercolordark="#000000">
             
		<? 
         $sel="select cp.product_desc from corelcase_product_maptbl as map left join corel_product_tbl
 as cp on map.corelproduct_id=cp.product_id where corelcase_id=".$thearray['corel_id'];
       // echo $sel;
         $get_pro=mysql_query($sel);
            ?>
            <td> 
            <? 
              $j=$j=1;
              while($pro = mysql_fetch_array($get_pro))
      		{
               echo $j.") "; echo $pro['product_desc']; echo ("<br>");
               $j++;
		}
              
		?>
             </td>
              </tr>
           </table></td>
          <!--Product End--->


        <!--Product Rate--->
		<!--<td align="left">
              <table >
              <tr style="font-family: Verdana; font-size: 8pt; color: #000000" bordercolordark="#000000">
             
		<? 
         $sel="select cp.product_price from corelcase_product_maptbl as map left join corel_product_tbl
 as cp on map.corelproduct_id=cp.product_id where corelcase_id=".$thearray['corel_id'];
       // echo $sel;
         $get_pro=mysql_query($sel);
            ?>
            <td> 
            <? 
              $j=$j=1;
              while($pro = mysql_fetch_array($get_pro))
      		{
               echo $j.") "; echo $pro['product_price']; echo ("<br>");
               $j++;
		}
              
		?>
             </td>
              </tr>
           </table></td>-->

        <!--Product Rate End-->
        
		        
		<td align="center"><? if($thearray['corel_upsell']=="") echo " - "; else echo $thearray['corel_upsell']; ?></td>        
				<!---Upsell Product---->
		<td align="left">
              <table border=0>
              <tr style="font-family: Verdana; font-size: 8pt; color: #000000" bordercolordark="#000000">
             
		<? 
         $sel="select cup.upsell_product_desc from corelcase_upsellproduct_maptbl as map left join corel_upsellproduct_tbl
 as cup on map.corelupsellproduct_id=cup.upsell_product_id where corelcase_id=".$thearray['corel_id'];
        //echo $sel;
         $get_pro=mysql_query($sel);
            ?>
            <td> 
            <? 
              $j=$j=1;
              while($pro1 = mysql_fetch_array($get_pro))
      		{
               echo $j.") "; echo $pro1['upsell_product_desc']; echo ("<br>");
               $j++;
		}
              
		?>
             </td>
              </tr>
           </table></td>
          <!--Upsell Product End--->
          

        
						<!---Upsell Product Rate---->
		<!--<td align="left">
              <table border=0>
              <tr style="font-family: Verdana; font-size: 8pt; color: #000000" bordercolordark="#000000">
             
		<? 
         $sel="select cp.upsell_product_price from corelcase_upsellproduct_maptbl as map left join corel_upsellproduct_tbl
 as cp on map.corelcase_upsellproduct_mapid=cp.upsell_product_id where corelcase_id=".$thearray['corel_id'];
       // echo $sel;
         $get_pro=mysql_query($sel);
            ?>
            <td> 
            <? 
              $j=$j=1;
              while($pro = mysql_fetch_array($get_pro))
      		{
               echo $j.") "; echo $pro['upsell_product_price']; echo ("<br>");
               $j++;
		}
              
		?>
             </td>
              </tr>
           </table></td>-->
          <!--Upsell Product Rate End--->

          <td align="center"><? if($thearray['updecreason_desc']=='') echo " - "; else echo $thearray['updecreason_desc']; ?></td>
		  <td align="center"><? if($thearray['corel_upsell_othreason']=='') echo " - "; else echo $thearray['corel_upsell_othreason']; ?></td>		
          <td align="center"><? if($thearray['corel_shipping']=="") echo " - "; else echo $thearray['corel_shipping']; ?></td> 		
		<td align="center"><? if($thearray['shipping_desc']=="") echo " - "; else echo $thearray['shipping_desc']; ?></td>		
		<td align="center"><? if($thearray['shipping_price']=="") echo " - "; else echo $thearray['shipping_price']; ?></td>        
		<td align="center"><? if($thearray['corel_reason_decline']=="") echo " - "; else echo $thearray['corel_reason_decline']; ?></td>		
        <td align="left"><? echo $thearray['corel_comm']; ?></td>
		<td align="center"><? if($thearray['corel_discount']=="") echo " - "; else echo $thearray['corel_discount']; ?></td>
		<td align="center">Sales</td>
    </tr>
<?php
             $sno++;
          }
?>
</table>
