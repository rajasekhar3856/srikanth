<?php
include 'dbconn.php';
include 'Classes/PHPExcel.php';
include 'Classes/PHPExcel/IOFactory.php';

// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Create a first sheet, representing sales data
$objPHPExcel->setActiveSheetIndex(0);

//$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Something');
// $columnHeader = '';  
// $columnHeader = "Sr NO" . "\t" . "Locatin Code" . "\t". "Locatin Name" . "\t". "Currency Code" . "\t". "Status" . "\t";  
	

$setSql = "SELECT * FROM location";  
$setRec = mysqli_query($dbconn, $setSql);  
$objPHPExcel->setActiveSheetIndex(0);
// $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Id');
// $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Location Code');
// $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Locatin Name');
// $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Currency Code');
// $objPHPExcel->getActiveSheet()->SetCellValue('e1', 'Status');
$fC=1;
		$fChar='A';
	while ($fieldinfo=mysqli_fetch_field($setRec))
    {
		$objPHPExcel->getActiveSheet()->SetCellValue($fChar++.''.$fC, $fieldinfo->name );
		//$header .= $fieldinfo->name . "\t";
    }
	  
	  
$fC=2;
while($row=mysqli_fetch_array($setRec,MYSQLI_BOTH)){
	
$fChar='A';
$f=0;
	while($f<mysqli_num_fields($setRec)){
        $objPHPExcel->getActiveSheet()->setCellValue($fChar++.''.$fC, $row[$f]);
		$f++;
    }

$fC++;  
}


// Rename sheet
$objPHPExcel->getActiveSheet()->setTitle('Locatin');

// Create a new worksheet, after the default sheet
$objPHPExcel->createSheet();

// Add some data to the second sheet, resembling some different data types
$objPHPExcel->setActiveSheetIndex(1);

$setSql = "SELECT * FROM language";  
$setRec = mysqli_query($dbconn, $setSql);  

$fC=1;
		$fChar='A';
	while ($fieldinfo=mysqli_fetch_field($setRec))
    {
		$objPHPExcel->getActiveSheet()->SetCellValue($fChar++.''.$fC, $fieldinfo->name );
		//$header .= $fieldinfo->name . "\t";
    }


$fC=2;
while($row=mysqli_fetch_array($setRec,MYSQLI_BOTH)){
	
$fChar='A';
$f=0;
	while($f<mysqli_num_fields($setRec)){
        $objPHPExcel->getActiveSheet()->setCellValue($fChar++.''.$fC, $row[$f]);
		$f++;
    }

$fC++;  
}


// Rename 2nd sheet
$objPHPExcel->getActiveSheet()->setTitle('Channel');

// Create a new worksheet, after the default sheet
$objPHPExcel->createSheet();

// Add some data to the second sheet, resembling some different data types
$objPHPExcel->setActiveSheetIndex(2);

$setSql = "SELECT * FROM channel";  
$setRec = mysqli_query($dbconn, $setSql);  


$fC=1;
		$fChar='A';
	while ($fieldinfo=mysqli_fetch_field($setRec))
    {
		$objPHPExcel->getActiveSheet()->SetCellValue($fChar++.''.$fC, $fieldinfo->name );
		//$header .= $fieldinfo->name . "\t";
    }

$fC=2;
while($row=mysqli_fetch_array($setRec,MYSQLI_BOTH)){
	
$fChar='A';
$f=0;
	while($f<mysqli_num_fields($setRec)){
        $objPHPExcel->getActiveSheet()->setCellValue($fChar++.''.$fC, $row[$f]);
		$f++;
    }

$fC++;  
}


// Rename 2nd sheet
$objPHPExcel->getActiveSheet()->setTitle('Language');

// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="name_of_file.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
?>